package com.rnrsolutions.greenbless;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainApplication {
    public static void main(String[] args) {
        SpringApplication.run(com.rnrsolutions.greenbless.MainApplication.class, args);
    }
}