package com.rnrsolutions.greenbless.device_environment.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeviceEnvironmentEntity1DTO {
    private int id;

    private String deviceID;
    private String deviceType;
}
