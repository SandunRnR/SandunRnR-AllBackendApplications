package com.rnrsolutions.greenbless.forecast.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ForecastTypeDTO {
    private int ID;

    private String name;
    private char contributionOrder;
}
